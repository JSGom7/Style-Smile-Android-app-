package com.mjosephg.stylesmile;

import java.io.Serializable;
import java.text.NumberFormat;


public class Appointment implements Serializable{
    private String firstName, lastName, email, phone, day, time;
    private String serviceDesired, stylistDesired;
    private String subtotal, tipAmount, totalAmount;

    public Appointment() {
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getDay() {
        return day;
    }

    public String getTime() {
        return time;
    }

    public String getServiceDesired() {
        return serviceDesired;
    }

    public String getStylistDesired() { return stylistDesired; }

    public String getSubtotal(){return subtotal;}

    public String gettotalAmount(){return totalAmount;}

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setDay(String day) {
        this.day = day;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setServiceDesired(String serviceDesired) {
        this.serviceDesired = serviceDesired;
    }

    public void setStylistDesired(String stylistDesired) {
        this.stylistDesired = stylistDesired;
    }


    public void setSubtotal (int splitPosition){

        NumberFormat currency = NumberFormat.getCurrencyInstance();

        if (splitPosition == 0){
            subtotal = currency.format(16);}
        if (splitPosition == 1){
            subtotal =  currency.format(19);}
        if (splitPosition == 2){
            subtotal =  currency.format(35);}
        if (splitPosition == 3){
            subtotal = currency.format (45);}
        if (splitPosition == 4){
            subtotal =  currency.format(27);}
        if (splitPosition == 5){
            subtotal =  currency.format(10);}


    }

    public void settotalAmount (float subtotal, float tipAmount ){

        NumberFormat currency = NumberFormat.getCurrencyInstance();

        totalAmount = currency.format(subtotal + tipAmount);
    }


}
