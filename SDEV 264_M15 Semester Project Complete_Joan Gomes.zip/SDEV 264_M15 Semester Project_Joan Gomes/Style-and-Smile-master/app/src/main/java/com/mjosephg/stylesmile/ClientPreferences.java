package com.mjosephg.stylesmile;


public class ClientPreferences {
    private ClientPreferences clientPreferences;
    private String sex, age, language;

    private ClientPreferences() {
    }

    public ClientPreferences getClientPreferences() {
        if (this.clientPreferences == null){
            clientPreferences = new ClientPreferences();
        }
        return clientPreferences;
    }

    public String getSex() {
        return sex;
    }

    public String getAge() {
        return age;
    }

    public String getLanguage() {
        return language;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setLanguage(String language) {
        this.language = language;
    }
}
