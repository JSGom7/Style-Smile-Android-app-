package com.mjosephg.stylesmile;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.text.NumberFormat;


public class Fragment1 extends Fragment {
    private static final String TAG = "Fragment1";

    private Spinner splitDay;
    private Spinner splitTime;
    private Spinner splitService;
    private Spinner splitStylist;
    private Button submitButton;
    private EditText firstName;
    private EditText lastName;
    private EditText email;
    private EditText phone;


    SubmitClicked update;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable final Bundle savedInstanceState) {
        View view  = inflater.inflate(R.layout.fragment1_layout, container, false);
        splitDay = (Spinner) view.findViewById(R.id.splitDay);
        splitTime = (Spinner) view.findViewById(R.id.splitTime);
        splitService = (Spinner) view.findViewById(R.id.splitService);
        splitStylist = (Spinner) view.findViewById(R.id.splitStylist);


        firstName = (EditText) view.findViewById(R.id.firstNameEditText);
        lastName = (EditText) view.findViewById(R.id.lastNameEditText);
        email = (EditText) view.findViewById(R.id.emailEditText);
        phone = (EditText) view.findViewById(R.id.phoneEditText);


        try {
            update = (SubmitClicked) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString()
                    + " must implement TextClicked");
        }
        // set array adapter for spinner
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                getActivity(), R.array.split_day, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        splitDay.setAdapter(adapter);

        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(
                getActivity(), R.array.split_time, android.R.layout.simple_spinner_item);
        adapter1.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        splitTime.setAdapter(adapter1);

        ArrayAdapter<CharSequence> adapter2 = ArrayAdapter.createFromResource(
                getActivity(), R.array.split_service, android.R.layout.simple_spinner_item);
        adapter2.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        splitService.setAdapter(adapter2);

        ArrayAdapter<CharSequence> adapter3 = ArrayAdapter.createFromResource(
                getActivity(), R.array.split_stylist, android.R.layout.simple_spinner_item);
        adapter3.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);
        splitStylist.setAdapter(adapter3);



        submitButton = (Button) view.findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Appointment appointment = new Appointment();
                appointment.setFirstName(firstName.getText().toString());
                appointment.setLastName(lastName.getText().toString());
                appointment.setEmail(email.getText().toString());
                appointment.setPhone(phone.getText().toString());
                appointment.setDay(splitDay.getSelectedItem().toString());
                appointment.setTime(splitTime.getSelectedItem().toString());
                appointment.setServiceDesired(splitService.getSelectedItem().toString());
                appointment.setStylistDesired(splitStylist.getSelectedItem().toString());

                int splitPosition = splitService.getSelectedItemPosition();

                appointment.setSubtotal(splitPosition);



                update.updateAppointment(appointment);
                ((MainActivity)getActivity()).setViewPager(1);
//                Intent intent = new Intent(getActivity().getApplicationContext(), SecondaryActivity.class);
//                intent.putExtra("AppointInfo", (Serializable) appointment);
//                startActivity(intent);
            }
        });


        return view;
    }




    public interface SubmitClicked{
        public void updateAppointment(Appointment appointment);
    }
}

