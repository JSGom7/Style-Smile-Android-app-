package com.mjosephg.stylesmile;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.view.KeyEvent;


import java.text.NumberFormat;


public class Fragment2 extends Fragment {
    private static final String TAG = "Fragment1";

    TextView firstName, lastName, email, phone, day, time, service, stylist;
    Button confirm;
    Appointment appointment;
    private TextView subtotalTextView;
    private EditText tipAmount;
    private TextView totalTextView;
    private Spinner splitService;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable final Bundle savedInstanceState) {
        View view  = inflater.inflate(R.layout.fragment2_layout, container, false);
        Log.d(TAG, "onCreateView: started.");
        firstName = (TextView) view.findViewById(R.id.firstNameTextView);
        lastName = (TextView) view.findViewById(R.id.lastNameTextView);
        email = (TextView) view.findViewById(R.id.emailTextView);
        phone = (TextView) view.findViewById(R.id.phoneTextView);
        day = (TextView) view.findViewById(R.id.dayTextView);
        time = (TextView) view.findViewById(R.id.timeTextView);
        service = (TextView) view.findViewById(R.id.serviceTextView);
        stylist = (TextView) view.findViewById(R.id.stylistTextView);
        confirm = (Button) view.findViewById(R.id.confirmButton);
        tipAmount = (EditText) view.findViewById(R.id.tipEditText);
        subtotalTextView= (TextView)view.findViewById(R.id.subtotalTextView);
        totalTextView= (TextView)view.findViewById(R.id.totalTextView);
        splitService = (Spinner)view.findViewById(R.id.splitService);




        tipAmount.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, android.view.KeyEvent event) {

                if (actionId == EditorInfo.IME_ACTION_DONE) {

                    float subtotal = Float.parseFloat(subtotalTextView.getText().toString());
                    String tipAmountString = tipAmount.getText().toString();
                    float TipAmount = Float.parseFloat(tipAmountString);

                    appointment.settotalAmount(subtotal, TipAmount);

                }



                return false;
            }

        });






        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity(), "Appointment Confirmed", Toast.LENGTH_LONG).show();

            }
        });




        return view;
    }

    public void updateAppointment(Appointment appointment){

        this.appointment = appointment;
        firstName.setText(appointment.getFirstName());
        lastName.setText(appointment.getLastName());
        email.setText(appointment.getEmail());
        phone.setText(appointment.getPhone());
        day.setText(appointment.getDay());
        service.setText(appointment.getServiceDesired());
        time.setText(appointment.getTime());
        stylist.setText(appointment.getStylistDesired());
        subtotalTextView.setText(appointment.getSubtotal());
        totalTextView.setText(appointment.gettotalAmount());




    }


}
