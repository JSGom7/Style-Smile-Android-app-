package com.mjosephg.stylesmile;

import android.os.Bundle;
import android.app.Activity;
import android.widget.TextView;

public class SecondaryActivity extends Activity {

    TextView firstName, lastName, email, phone, day, time, service, stylist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondary);
        Appointment appointment = (Appointment) getIntent().getSerializableExtra("AppointInfo");

        firstName = (TextView) findViewById(R.id.firstNameTextView);
        lastName = (TextView) findViewById(R.id.lastNameTextView);
        email = (TextView) findViewById(R.id.emailTextView);
        phone = (TextView) findViewById(R.id.phoneTextView);
        day = (TextView) findViewById(R.id.dayTextView);
        time = (TextView) findViewById(R.id.timeTextView);
        service = (TextView) findViewById(R.id.serviceTextView);
        stylist = (TextView) findViewById(R.id.stylistTextView);

        firstName.setText(appointment.getFirstName());
        lastName.setText(appointment.getLastName());
        email.setText(appointment.getEmail());
        phone.setText(appointment.getPhone());
        day.setText(appointment.getDay());
        service.setText(appointment.getServiceDesired());
        time.setText(appointment.getTime());
        stylist.setText(appointment.getStylistDesired());
    }

}
